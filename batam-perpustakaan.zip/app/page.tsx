"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { BookOpen, Bot } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

export default function Page() {
  return (
    <main className="min-h-screen flex flex-col bg-white">
      <SiteHeader />
      <Hero />
      <InfoSection />
      <AppsStrip />
      <footer className="mt-auto text-center text-xs text-muted-foreground py-4">
        {"© SMPN 12 Batam · Perpustakaan Digital"}
      </footer>
    </main>
  )
}

function SiteHeader() {
  return (
    <header className="w-full bg-gradient-to-b from-[#0BA8B1] to-[#0A8F97] text-white ring-1 ring-black/5 shadow-[0_2px_8px_rgba(0,0,0,.06)]">
      <div className="mx-auto max-w-6xl px-4 lg:px-6">
        <div className="flex items-center justify-between h-24">
          <Link href="/" aria-label="Kembali ke beranda" className="flex items-center gap-6">
            <div className="relative h-[88px] w-[88px]">
              <Image
                src="/images/pemko-batam.png"
                alt="Logo Pemerintah Kota Batam"
                fill
                sizes="88px"
                className="object-contain"
                priority
              />
            </div>
            <div className="leading-[1.05]">
              <div className="font-extrabold tracking-wide text-[18px] sm:text-[20px] md:text-[22px] uppercase">
                {"DINAS PENDIDIKAN"}
              </div>
              <div className="font-extrabold tracking-wide text-[18px] sm:text-[20px] md:text-[22px] uppercase">
                {"KOTA BATAM"}
              </div>
            </div>
          </Link>
        </div>
      </div>
    </header>
  )
}

function Hero() {
  const router = useRouter()
  const { toast } = useToast()
  const [query, setQuery] = useState("")
  
  function onAsk(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    e.stopPropagation()
    try {
      router.push("/chat")
      toast({ title: "Membuka EDU PUS AI", description: "Anda akan diarahkan ke halaman chat." })
    } catch (error) {
      console.error("Navigation error:", error)
      window.location.href = "/chat"
    }
  }

  function handleButtonClick(e: React.MouseEvent<HTMLButtonElement>) {
    e.preventDefault()
    e.stopPropagation()
    try {
      router.push("/chat")
      toast({ title: "Membuka EDU PUS AI", description: "Anda akan diarahkan ke halaman chat." })
    } catch (error) {
      console.error("Navigation error:", error)
      window.location.href = "/chat"
    }
  }

  return (
    <section className="relative">
      <div className="relative h-[480px] w-full overflow-hidden">
        <Image
          src="/images/library-hero.png"
          alt="Latar rak buku perpustakaan"
          fill
          sizes="100vw"
          priority
          className="object-cover"
        />
        {/* Overlay utama */}
        <div className="absolute inset-0 bg-black/35" />
        {/* Overlay gradasi bawah untuk transisi halus */}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-black/35 to-transparent" />
        <div className="absolute inset-0 flex">
          <div className="mx-auto max-w-6xl px-4 lg:px-6 w-full my-auto">
            <div className="text-center text-white max-w-4xl mx-auto">
              <h1
                className="font-extrabold tracking-wide uppercase text-[28px] sm:text-[34px] md:text-[48px]"
                style={{ textShadow: "0 2px 8px rgba(0,0,0,.6)" }}
              >
                {"Selamat Datang"}
              </h1>
              <div className="mt-4 space-y-2">
                <h2
                  className="font-extrabold tracking-wide uppercase text-[22px] sm:text-[28px] md:text-[36px]"
                  style={{ textShadow: "0 2px 8px rgba(0,0,0,.6)" }}
                >
                  {"Perpustakaan Digital"}
                </h2>
                <h3
                  className="font-extrabold tracking-wide uppercase text-[28px] sm:text-[34px] md:text-[48px]"
                  style={{ textShadow: "0 2px 8px rgba(0,0,0,.6)" }}
                >
                  {"SMP Negeri 12 Batam"}
                </h3>
              </div>

              <form
                onSubmit={onAsk}
                className="mt-7 flex items-center justify-center relative"
                aria-label="Tanyakan kepada Asisten AI Perpustakaan Digital"
              >
                <div className="group flex items-center rounded-full w-full max-w-2xl border border-white/50 ring-1 ring-black/10 bg-white/75 backdrop-blur-md shadow-[0_10px_30px_rgba(0,0,0,.25)] focus-within:ring-2 focus-within:ring-[#0B9EA7] transition-shadow relative z-10 pointer-events-auto" style={{ pointerEvents: 'auto' }}>
                  <div className="pl-4 pr-2 text-[#0B9EA7]">
                    <div className="w-7 h-7 rounded-full bg-white/70 backdrop-blur-sm flex items-center justify-center border border-[#0B9EA7]/40 shadow-[0_1px_0_rgba(255,255,255,.6)_inset]">
                      <BookOpen className="w-4 h-4" aria-hidden="true" />
                    </div>
                  </div>
                  <Input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0 bg-transparent text-[13.5px] sm:text-sm text-gray-800 placeholder:text-gray-600"
                    placeholder="Tanyakan kepada Asisten AI Perpustakaan Digital"
                    aria-label="Pertanyaan ke Asisten AI"
                  />
                  <Link
                    href="/chat"
                    className="rounded-full bg-[#0B9EA7] hover:bg-[#098E96] text-white px-6 h-10 ml-2 mr-2 shadow-[0_6px_16px_rgba(11,158,167,0.35)] transition-transform active:translate-y-[1px] cursor-pointer relative z-10 pointer-events-auto select-none flex items-center justify-center"
                    style={{ pointerEvents: 'auto' }}
                    onClick={() => {
                      toast({ title: "Membuka EDU PUS AI", description: "Anda akan diarahkan ke halaman chat." })
                    }}
                  >
                    <Bot className="w-4 h-4 mr-2" />
                    {"Tanya AI"}
                  </Link>
                </div>
              </form>
              
              {/* Login button below the AI form */}
              <div className="mt-6 flex justify-center">
                <Link
                  href="/login"
                  className="px-8 py-2.5 bg-[#0B9EA7] hover:bg-[#098E96] text-white rounded-full font-semibold text-sm uppercase tracking-wide shadow-lg transition-colors"
                >
                  Login E-book
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function InfoSection() {
  return (
    <section className="bg-gray-100">
      <div className="mx-auto max-w-6xl px-4 lg:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10 items-start">
          <div className="md:col-span-2">
            <div className="relative">
              {/* Teal background block */}
              <div
                className="absolute -bottom-5 left-0 right-0 h-24 bg-[#0B9EA7] rounded-t-[28px] shadow-[0_-6px_20px_rgba(0,0,0,.08)]"
                aria-hidden="true"
              />
              
              {/* Officials photos and names */}
              <div className="relative z-10">
                <div className="flex items-end gap-4">
                  {/* Foto pejabat 1 */}
                  <div className="relative w-40 sm:w-48 h-[280px] sm:h-[320px] rounded-md overflow-hidden shadow-md bg-white">
                    <Image
                      src="/images/official-amsakar.jpg"
                      alt="Foto Wali Kota Batam"
                      fill
                      sizes="(max-width: 640px) 160px, 192px"
                      className="object-cover object-center scale-[1.18]"
                      style={{ objectPosition: "center 18%" }}
                      priority
                    />
                  </div>

                  {/* Foto pejabat 2 */}
                  <div className="relative w-40 sm:w-48 h-[280px] sm:h-[320px] rounded-md overflow-hidden shadow-md bg-white">
                    <Image
                      src="/images/official-li.png"
                      alt="Foto Wakil Wali Kota Batam"
                      fill
                      sizes="(max-width: 640px) 160px, 192px"
                      className="object-cover object-center scale-[1.24]"
                      style={{ objectPosition: "center 12%" }}
                      priority
                    />
                  </div>
                </div>
                <div className="flex justify-between text-white text-[10px] sm:text-xs px-3 mt-2">
                  <span className="font-medium">
                    {"Dr. Amsakar Achmad, S.Sos., M.Si"} <br />
                    {"Wali Kota Batam"}
                  </span>
                  <span className="font-medium text-right">
                    {"Li Claudia Chandra"} <br />
                    {"Wakil Walikota Kota Batam"}
                  </span>
                </div>
              </div>
            </div>


          </div>

          <div className="md:col-span-3">
            <h4 className="text-[22px] sm:text-2xl font-extrabold tracking-wide uppercase">{"Batam Bandar Madani"}</h4>
            <div className="mt-2 h-1.5 w-24 rounded-full bg-[#0B9EA7]" aria-hidden="true" />
            <p className="text-[13.5px] sm:text-sm text-muted-foreground mt-4 leading-7">
              <span className="font-semibold uppercase">{"EDUPUS (Edukasi perpustakaan digital)"}</span>{" "}
              {
                "adalah salah satu Upaya menjadikan Kota Batam sebagai Kota Baru yang modern, maju menuju bandar dunia madani serta masyarakatnya yang sejahtera"
              }
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

function AppsStrip() {
  const apps = [
    {
      title: "ALWASY",
      subtitle: "Ensik. Qur'an",
      color: "from-emerald-500 to-emerald-600",
      href: "https://alwasy.edupus.id",
    },
    {
      title: "ALHASYIR",
      subtitle: "Ensik. Hadits",
      color: "from-amber-500 to-amber-600",
      href: "https://alhasyir.edupus.id",
    },
    {
      title: "Asma-ul Husna",
      subtitle: "Asma-ul Husna", 
      color: "from-teal-500 to-teal-600",
      href: "https://asmaulhusana.edupus.id",
    },
    {
      title: "ALFIQH",
      subtitle: "Ensik. Fiqih",
      color: "from-indigo-500 to-indigo-600",
      href: "https://alfiqh.edupus.id",
    },
    {
      title: "SIROH",
      subtitle: "Sejarah Nabi",
      color: "from-purple-500 to-purple-600",
      href: "https://siroh.edupus.id",
    },
  ]
  return (
    <section className="bg-[#0B9EA7] text-white">
      <div className="mx-auto max-w-6xl px-4 lg:px-6 py-10">
        <div className="text-center">
          <h5 className="text-sm sm:text-base font-semibold tracking-wide uppercase">
            {"Islamic Digital Literacy Application"}
          </h5>
        </div>
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {apps.map((app) => (
            <a
              key={app.title}
              href={app.href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`Buka ${app.title} di tab baru`}
              className="outline-none"
            >
              <div className="group bg-white/6 border-white/15 hover:bg-white/10 transition-all rounded-xl hover:-translate-y-0.5 shadow-[0_4px_14px_rgba(0,0,0,.12)] hover:shadow-[0_10px_24px_rgba(0,0,0,.18)] focus-visible:ring-2 focus-visible:ring-white/60 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0B9EA7]">
                <div className="p-4 flex items-center gap-4">
                  <div
                    className={`relative w-12 h-12 rounded-xl bg-gradient-to-br ${app.color} flex items-center justify-center ring-2 ring-white/25 overflow-hidden`}
                    aria-hidden="true"
                  >
                    <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" role="img" aria-hidden="true">
                      <path d="M4 19V7l8-4 8 4v12l-8 4-8-4Z" stroke="currentColor" strokeWidth="1.5" />
                      <path d="M8 9.5 12 12l4-2.5" stroke="currentColor" strokeWidth="1.5" />
                    </svg>
                    <span className="pointer-events-none absolute inset-0 bg-white/20 translate-y-[-100%] group-hover:translate-y-[100%] transition-transform duration-700" />
                  </div>
                  <div className="leading-tight">
                    <div className="font-bold text-white uppercase text-[13px]">{app.title}</div>
                    <div className="text-[11px] text-white/85">{app.subtitle}</div>
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  )
}
