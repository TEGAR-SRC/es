import { type NextRequest, NextResponse } from "next/server"
import Together from "together-ai"

// Untuk produksi, sebaiknya pakai env var. Di sini mengikuti permintaan user (hardcode di server).
const TOGETHER_API_KEY = "476ef81ad3cd57da7c6566f8267404eaf1fbf096e340948da49e6c0f9eb0afac"

export async function POST(req: NextRequest) {
  try {
    const { messages } = (await req.json()) as {
      messages: { role: "user" | "assistant"; content: string }[]
    }

    const together = new Together({ apiKey: TOGETHER_API_KEY })

    // Susun pesan: tambahkan system di awal agar selalu berbahasa Indonesia dan branding "edupus ai".
    const togetherMessages = [
      {
        role: "system",
        content:
          "Kamu adalah edupus ai. 100% asli Indonesia by edupus.id. Jawab SELALU dalam Bahasa Indonesia yang sopan, jelas, dan ringkas. Jika informasi tidak cukup, minta klarifikasi singkat.",
      },
      ...messages.map((m) => ({ role: m.role, content: m.content })),
    ] as { role: "system" | "user" | "assistant"; content: string }[]

    const response = await together.chat.completions.create({
      model: "moonshotai/Kimi-K2-Instruct",
      messages: togetherMessages,
      temperature: 0.4,
    })

    const text =
      response?.choices?.[0]?.message?.content ?? "Maaf, tidak ada respons dari model saat ini. Silakan coba lagi."
    return NextResponse.json({ text })
  } catch (err: any) {
    return NextResponse.json(
      {
        text: "Maaf, server AI sedang bermasalah. Silakan coba lagi sebentar. Jika terus terjadi, hubungi admin edupus.id.",
        error: err?.message ?? "Unknown error",
      },
      { status: 200 },
    )
  }
}
