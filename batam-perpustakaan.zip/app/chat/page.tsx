"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { 
  Send, Bot, User, ArrowLeft, Plus, Trash2, Settings, 
  MessageSquare, Mic, Copy, Share2, Code, FileText,
  Upload, Download, Menu, X, ChevronDown, Terminal, 
  Image, Zap, BookOpen, Users, LogOut, Search, LayoutGrid
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { toast } from "sonner"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

type ModelType = "standard" | "pro" | "advanced"

type ChatSettings = {
  model: ModelType
  temperature: number
  maxLength: number
}

type ChatMessage = {
  role: "user" | "assistant"
  content: string
  timestamp?: Date
}

type ChatSession = {
  id: string
  title: string
  messages: ChatMessage[]
  createdAt: Date
}

type MenuItem = {
  id: string
  label: string
  icon: React.ReactNode
  isNew?: boolean
}

type QuickAction = {
  id: string
  label: string
  icon: React.ReactNode
}

type Panel = {
  id: string
  messages: ChatMessage[]
  input: string
  model: ModelType
}

// Update ContentView type definition
type ContentView = "chat" | "ide" | "api" | "docs" | "agents" | "history"

// Add after existing type definitions
type UserData = {
  name: string
  registeredAt: Date
}

export default function ChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content:
        "Halo, saya edupus ai. 100% asli Indonesia by edupus.id. Ada yang bisa saya bantu terkait perpustakaan digital?",
    },
  ])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false) // Default closed on mobile
  const [chatHistory, setChatHistory] = useState<{id: string, title: string}[]>([])
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null)
  const [sessions, setSessions] = useState<ChatSession[]>([])
  const [isRecording, setIsRecording] = useState(false)
  const [selectedModel, setSelectedModel] = useState<ModelType>("standard")
  const [showSettings, setShowSettings] = useState(false)
  const [settings, setSettings] = useState<ChatSettings>({
    model: "standard",
    temperature: 0.7,
    maxLength: 2048
  })
  const [files, setFiles] = useState<File[]>([])
  const [panels, setPanels] = useState<Panel[]>([])
  const [showPanels, setShowPanels] = useState(false)
  const [currentView, setCurrentView] = useState<ContentView>("chat")
  const [userName, setUserName] = useState<string>("")
  const [isRegistered, setIsRegistered] = useState<boolean>(false)
  const endRef = useRef<HTMLDivElement | null>(null)
  const fileInputRef = useRef<HTMLInputElement | null>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages, loading])

  // Add useEffect to check localStorage on component mount
  useEffect(() => {
    const userData = localStorage.getItem('edupus_user')
    if (userData) {
      const user = JSON.parse(userData)
      setUserName(user.name)
      setIsRegistered(true)
    }
    
    // Set sidebar open on desktop, closed on mobile
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setSidebarOpen(true)
      } else {
        setSidebarOpen(false)
      }
    }
    
    handleResize()
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault()
    e.stopPropagation()
    const text = input.trim()
    if (!text) return
    
    // Clear input immediately to prevent lag
    setInput("")
    
    const nextMessages = [...messages, { role: "user" as const, content: text }]
    setMessages(nextMessages)
    setLoading(true)
    
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages }),
      })
      if (!res.ok) throw new Error("Gagal menghubungi server AI")
      const data = (await res.json()) as { text: string }
      setMessages((prev) => [...prev, { role: "assistant", content: data.text }])
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            "Maaf, terjadi kendala saat menghubungi layanan AI. Silakan coba lagi sebentar, atau periksa koneksi internet Anda.",
        },
      ])
    } finally {
      setLoading(false)
    }
  }

  // Update the handleKeyDown function
  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      e.stopPropagation()
      if (!loading && input.trim()) {
        sendMessage(e as any)
      }
    }
  }

  function startNewChat() {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: "Chat Baru",
      messages: [{
        role: "assistant",
        content: "Halo, saya EDUPUS-AI. Ada yang bisa saya bantu terkait perpustakaan digital?",
        timestamp: new Date()
      }],
      createdAt: new Date()
    }
    setSessions(prev => [newSession, ...prev])
    setActiveSessionId(newSession.id)
    setMessages(newSession.messages)
  }

  function clearHistory() {
    if (confirm("Anda yakin ingin menghapus semua riwayat chat?")) {
      setSessions([])
      setActiveSessionId(null)
      startNewChat()
      toast.success("Riwayat chat berhasil dihapus")
    }
  }

  async function copyMessage(content: string) {
    await navigator.clipboard.writeText(content)
    toast.success("Pesan berhasil disalin")
  }

  async function toggleVoiceRecording() {
    if (!isRecording) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
        setIsRecording(true)
        // Implementasi logika perekaman
        toast.info("Mulai merekam...")
      } catch (err) {
        toast.error("Gagal mengakses mikrofon")
      }
    } else {
      setIsRecording(false)
      toast.success("Rekaman selesai")
      // Implementasi pengiriman hasil rekaman
    }
  }

  async function exportChat() {
    const chatData = {
      messages,
      settings,
      timestamp: new Date().toISOString()
    }
    const blob = new Blob([JSON.stringify(chatData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `chat-export-${Date.now()}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success("Chat berhasil diekspor")
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files
    if (files) {
      const file = files[0]
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        toast.error("File terlalu besar. Maksimal 10MB")
        return
      }
      setFiles(prev => [...prev, file])
      toast.success(`File ${file.name} berhasil diunggah`)
    }
  }

  function MessageBubble({ message }: { message: ChatMessage }) {
    const isUser = message.role === "user"
    
    return (
      <div className="group w-full text-gray-800 border-b border-gray-100">
        <div className="flex gap-2 p-2 sm:p-4 hover:bg-gray-50 transition-colors">
          <div className={`w-6 h-6 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
            isUser ? "bg-gray-700" : "bg-gray-100"
          }`}>
            {isUser ? (
              <User className="w-4 h-4 text-white" />
            ) : (
              <Bot className="w-4 h-4 text-gray-700" />
            )}
          </div>
          <div className="flex-1 min-w-0 space-y-1">
            <div className="flex justify-between items-center">
              <p className="text-xs font-medium text-gray-600">
                {isUser ? 'Anda' : 'EDUPUS-AI'}
              </p>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => copyMessage(message.content)}
                  className="p-1 hover:bg-gray-100 rounded"
                  type="button"
                >
                  <Copy className="w-3 h-3 text-gray-500" />
                </button>
                <button className="p-1 hover:bg-gray-100 rounded" type="button">
                  <Share2 className="w-3 h-3 text-gray-500" />
                </button>
              </div>
            </div>
            <div className="prose prose-sm max-w-none text-gray-600 text-sm break-words leading-relaxed whitespace-pre-wrap">
              {message.content}
            </div>
            {message.timestamp && (
              <p className="text-[10px] text-gray-400">
                {message.timestamp.toLocaleTimeString()}
              </p>
            )}
          </div>
        </div>
      </div>
    )
  }

  // Update menuItems to remove partnership and add handlers
  const menuItems: MenuItem[] = [
    { id: 'new-chat', label: 'Obrolan Baru', icon: <Plus className="w-4 h-4" /> },
    { id: 'history', label: 'Riwayat', icon: <MessageSquare className="w-4 h-4" /> },
    { id: 'image-to-app', label: 'Gambar ke Aplikasi', icon: <Image className="w-4 h-4" />, isNew: true },
    { id: 'agents', label: 'Agen', icon: <Bot className="w-4 h-4" /> },
    { id: 'ide', label: 'EDUPUS IDE', icon: <Terminal className="w-4 h-4" /> },
    { id: 'api', label: 'Platform API', icon: <Code className="w-4 h-4" /> },
    { id: 'docs', label: 'Dokumentasi', icon: <BookOpen className="w-4 h-4" /> }
  ]

  const quickActions: QuickAction[] = [
    { 
      id: 'app-builder', 
      label: 'Pembangun Aplikasi', 
      icon: <Code className="w-4 h-4" /> 
    },
    { 
      id: 'deep-research', 
      label: 'Penelitian Mendalam', 
      icon: <Search className="w-4 h-4" /> 
    },
    { 
      id: 'think', 
      label: 'Berpikir', 
      icon: <Zap className="w-4 h-4" /> 
    },
    { 
      id: 'upload', 
      label: 'Unggah', 
      icon: <Upload className="w-4 h-4" /> 
    },
    { 
      id: 'multi-panel', 
      label: 'Multi-Panel', 
      icon: <LayoutGrid className="w-4 h-4" /> 
    }
  ]

  // Add handlers for menu items
  function handleMenuClick(id: string) {
    switch(id) {
      case 'new-chat':
        startNewChat()
        setCurrentView("chat")
        break
      case 'agents':
        setCurrentView("agents")
        break
      case 'ide':
        setCurrentView("ide")
        break
      case 'api':
        setCurrentView("api")
        break
      case 'docs':
        setCurrentView("docs")
        break
      case 'history':
        if (sessions.length > 0) {
          setSidebarOpen(true)
          // Show history panel
          setCurrentView("history")
        } else {
          toast.info("Belum ada riwayat chat")
        }
        break
      case 'image-to-app':
        handleImageUpload()
        break
    }
  }

  // Add function to handle image upload and processing
  async function handleImageUpload() {
    try {
      // Create file input specifically for images
      const input = document.createElement('input')
      input.type = 'file'
      input.accept = 'image/*'
      input.onchange = async (e) => {
        const file = (e.target as HTMLInputElement).files?.[0]
        if (file) {
          if (file.size > 5 * 1024 * 1024) { // 5MB limit
            toast.error("Ukuran gambar terlalu besar (max 5MB)")
            return
          }

          // Show loading state
          setLoading(true)
          toast.loading("Memproses gambar...")

          try {
            // Create FormData
            const formData = new FormData()
            formData.append('image', file)

            // Send to API
            const res = await fetch('/api/analyze-image', {
              method: 'POST',
              body: formData
            })

            if (!res.ok) throw new Error("Gagal menganalisis gambar")

            const data = await res.json()
            
            // Add result to chat
            setMessages(prev => [...prev, 
              { role: "user", content: `[Uploaded Image: ${file.name}]` },
              { role: "assistant", content: data.analysis }
            ])

            toast.success("Gambar berhasil dianalisis")
          } catch (err) {
            toast.error("Gagal menganalisis gambar")
          } finally {
            setLoading(false)
          }
        }
      }
      input.click()
    } catch (err) {
      toast.error("Gagal mengakses file gambar")
    }
  }

  async function handlePanelSend(panelId: string, panelIndex: number) {
    const panel = panels[panelIndex]
    const text = panel.input.trim()
    if (!text) return

    const nextMessages = [...panel.messages, { role: "user" as const, content: text }]
    
    // Update panel messages
    const newPanels = [...panels]
    newPanels[panelIndex].messages = nextMessages
    newPanels[panelIndex].input = ''
    setPanels(newPanels)

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          messages: nextMessages,
          model: panel.model 
        }),
      })
      
      if (!res.ok) throw new Error("Gagal menghubungi server AI")
      
      const data = (await res.json()) as { text: string }
      
      // Update with AI response
      const updatedPanels = [...panels]
      updatedPanels[panelIndex].messages = [
        ...nextMessages,
        { role: "assistant", content: data.text, timestamp: new Date() }
      ]
      setPanels(updatedPanels)
    } catch (err) {
      toast.error("Gagal mengirim pesan di panel " + (panelIndex + 1))
    }
  }

  function AgentsView() {
    const agents = [
      { id: 'code', name: 'Code Assistant', icon: <Code className="w-6 h-6" /> },
      { id: 'research', name: 'Research Helper', icon: <Search className="w-6 h-6" /> },
      { id: 'library', name: 'Library Guide', icon: <BookOpen className="w-6 h-6" /> }
    ]

    return (
      <div className="p-4 sm:p-6 max-w-4xl mx-auto">
        <h2 className="text-xl font-semibold mb-4">Agen EDUPUS-AI</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {agents.map(agent => (
            <button
              key={agent.id}
              onClick={() => setInput(`@${agent.id} `)}
              className="flex items-center gap-3 p-4 rounded-lg border border-gray-200 hover:bg-gray-50"
            >
              <div className="p-2 bg-gray-100 rounded-lg">{agent.icon}</div>
              <div className="text-left">
                <h3 className="font-medium">{agent.name}</h3>
                <p className="text-sm text-gray-500">Ketik @{agent.id} untuk menggunakan</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    )
  }

  function IDEView() {
    return (
      <div className="p-4 sm:p-6 max-w-4xl mx-auto">
        <h2 className="text-xl font-semibold mb-4">EDUPUS IDE</h2>
        <div className="space-y-4">
          <div className="p-4 border border-gray-200 rounded-lg">
            <h3 className="font-medium mb-2">Code Assistant</h3>
            <div className="bg-gray-100 p-4 rounded-lg">
              <pre className="text-sm"><code>// Ketik kode atau tanyakan tentang pemrograman</code></pre>
            </div>
          </div>
          <button
            onClick={() => setInput("@code ")}
            className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800"
          >
            Mulai Coding
          </button>
        </div>
      </div>
    )
  }

  function APIView() {
    return (
      <div className="p-4 sm:p-6 max-w-4xl mx-auto">
        <h2 className="text-xl font-semibold mb-4">Platform API</h2>
        <div className="prose max-w-none">
          <div className="p-4 border border-gray-200 rounded-lg space-y-4">
            <h3 className="font-medium">API Endpoints</h3>
            <pre className="bg-gray-100 p-4 rounded-lg overflow-x-auto">
              <code>{`POST /api/chat
GET /api/models
POST /api/analyze`}</code>
            </pre>
            <p className="text-sm text-gray-600">
              Untuk menggunakan API, ketik @api diikuti dengan perintah Anda
            </p>
          </div>
        </div>
      </div>
    )
  }

  // Add new component for upcoming features info
  function ComingSoonFeatures() {
    const upcomingFeatures = [
      { 
        title: "Real-time Collaboration", 
        description: "Kolaborasi dengan pengguna lain secara real-time",
        eta: "Q3 2025"
      },
      { 
        title: "Advanced Code Generation", 
        description: "Generasi kode otomatis dengan berbagai bahasa pemrograman",
        eta: "Q4 2025"
      },
      { 
        title: "Database Integration", 
        description: "Integrasi dengan berbagai jenis database",
        eta: "November 2025"
      },
      { 
        title: "Custom AI Training", 
        description: "Pelatihan AI dengan data perpustakaan Anda",
        eta: "November 2025"
      }
    ]

    return (
      <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 mb-6">
        <div className="flex items-center gap-2 mb-3">
          <Zap className="w-5 h-5 text-blue-500" />
          <h3 className="font-medium text-blue-700">Fitur Yang Akan Datang</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {upcomingFeatures.map((feature, index) => (
            <div key={index} className="bg-white rounded-lg p-3 shadow-sm">
              <h4 className="font-medium text-gray-900">{feature.title}</h4>
              <p className="text-sm text-gray-600 mt-1">{feature.description}</p>
              <span className="inline-block mt-2 text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded">
                Rilis: {feature.eta}
              </span>
            </div>
          ))}
        </div>
      </div>
    )
  }

  // Update DocsView to include the coming soon features
  function DocsView() {
    return (
      <div className="p-4 sm:p-6 max-w-4xl mx-auto">
        <h2 className="text-xl font-semibold mb-4">Dokumentasi</h2>
        <div className="prose max-w-none space-y-6">
          <ComingSoonFeatures />
          <div className="p-4 border border-gray-200 rounded-lg">
            <h3 className="font-medium">Fitur Saat Ini</h3>
            <ul className="mt-2 space-y-2">
              <li>Multi-panel chat untuk beberapa percakapan sekaligus</li>
              <li>Integrasi dengan berbagai AI agent khusus</li>
              <li>Dukungan upload file dan analisis dokumen</li>
              <li>Voice input untuk kemudahan penggunaan</li>
              <li>Export dan import riwayat chat</li>
            </ul>
          </div>
          <div className="p-4 border border-gray-200 rounded-lg">
            <h3 className="font-medium">Panduan Penggunaan</h3>
            <ul className="mt-2 space-y-2">
              <li>Gunakan @mention untuk mengakses fitur spesifik</li>
              <li>Upload file untuk analisis kode atau dokumen</li>
              <li>Aktifkan multi-panel untuk beberapa chat sekaligus</li>
              <li>Tekan Enter untuk mengirim pesan</li>
              <li>Gunakan tombol mikrofon untuk input suara</li>
            </ul>
          </div>
        </div>
        <div className="mt-6 text-sm text-gray-500">
          <p>Versi: Beta 0.2.0</p>
          <p>Last Updated: November 2025</p>
        </div>
      </div>
    )
  }

  function RegistrationForm() {
    const [inputName, setInputName] = useState("")
    const [error, setError] = useState("")

    const handleRegistration = (e: React.FormEvent) => {
      e.preventDefault()
      const name = inputName.trim()

      if (!name) {
        setError("Nama tidak boleh kosong")
        return
      }

      // Check if name exists in localStorage
      const existingUsers = localStorage.getItem('edupus_users')
      const users: string[] = existingUsers ? JSON.parse(existingUsers) : []

      if (users.includes(name)) {
        setError("Nama sudah digunakan, silakan gunakan nama lain")
        return
      }

      // Save user data
      const userData: UserData = {
        name: name,
        registeredAt: new Date()
      }
      localStorage.setItem('edupus_user', JSON.stringify(userData))
      localStorage.setItem('edupus_users', JSON.stringify([...users, name]))

      setUserName(name)
      setIsRegistered(true)
      toast.success("Selamat datang, " + name)
    }

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
        <div className="bg-white rounded-lg p-6 w-full max-w-md">
          <h2 className="text-xl font-semibold mb-4">Selamat Datang di EDUPUS-AI</h2>
          <p className="text-gray-600 mb-4">
            Untuk melanjutkan, silakan masukkan nama Anda
          </p>
          <form onSubmit={handleRegistration} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nama
              </label>
              <Input
                type="text"
                value={inputName}
                onChange={(e) => {
                  setInputName(e.target.value)
                  setError("")
                }}
                placeholder="Masukkan nama Anda"
                className="w-full"
                autoFocus
              />
              {error && (
                <p className="text-sm text-red-500 mt-1">{error}</p>
              )}
            </div>
            <Button
              type="submit"
              className="w-full bg-gray-900 text-white hover:bg-gray-800"
            >
              Mulai Chat
            </Button>
          </form>
        </div>
      </div>
    )
  }

  // Add inside ChatPage component
  function handleLogout() {
    if (confirm("Anda yakin ingin keluar?")) {
      localStorage.removeItem('edupus_user')
      setUserName("")
      setIsRegistered(false)
      // Reset chat state
      setMessages([{
        role: "assistant",
        content: "Halo, saya edupus ai. 100% asli Indonesia by edupus.id. Ada yang bisa saya bantu terkait perpustakaan digital?",
      }])
      toast.success("Berhasil keluar")
    }
  }

  // Add handleQuickAction function inside ChatPage
  function handleQuickAction(id: string) {
    switch(id) {
      case 'app-builder':
        setInput(prev => prev + "@app-builder ")
        break
      case 'deep-research':
        setInput(prev => prev + "@research ")
        break
      case 'think':
        setInput(prev => prev + "@think ")
        break
      case 'upload':
        fileInputRef.current?.click()
        break
      case 'multi-panel':
        if (!showPanels) {
          setPanels([
            {
              id: 'panel-1',
              messages: [...messages],
              input: '',
              model: selectedModel
            },
            {
              id: 'panel-2',
              messages: [{
                role: "assistant",
                content: "Panel baru siap digunakan.",
                timestamp: new Date()
              }],
              input: '',
              model: selectedModel
            }
          ])
          setShowPanels(true)
          toast.success("Multi-panel mode aktif")
        } else {
          setPanels([])
          setShowPanels(false)
          toast.info("Multi-panel mode dinonaktifkan")
        }
        break
    }
  }

  // Add HistoryView component
  function HistoryView() {
    return (
      <div className="px-4 py-6 max-w-4xl mx-auto">
        <h2 className="text-lg font-semibold mb-4">Riwayat Chat</h2>
        {sessions.length === 0 ? (
          <div className="text-gray-500">Belum ada riwayat chat.</div>
        ) : (
          <ul className="space-y-3">
            {sessions.map((session) => (
              <li key={session.id} className="flex items-center justify-between bg-gray-50 rounded-lg p-3 border border-gray-100">
                <button
                  className="text-left flex-1"
                  onClick={() => {
                    setActiveSessionId(session.id)
                    setMessages(session.messages)
                    setCurrentView("chat")
                  }}
                >
                  <span className="font-medium text-gray-800">{session.title}</span>
                  <span className="block text-xs text-gray-500">
                    {session.createdAt instanceof Date
                      ? session.createdAt.toLocaleString()
                      : new Date(session.createdAt).toLocaleString()}
                  </span>
                </button>
                <button
                  className="ml-2 p-1 rounded hover:bg-red-50"
                  onClick={() => {
                    setSessions(sessions.filter((s) => s.id !== session.id))
                    if (activeSessionId === session.id) {
                      setActiveSessionId(null)
                      setMessages([
                        {
                          role: "assistant",
                          content:
                            "Halo, saya edupus ai. 100% asli Indonesia by edupus.id. Ada yang bisa saya bantu terkait perpustakaan digital?",
                        },
                      ])
                    }
                  }}
                  title="Hapus riwayat"
                >
                  <Trash2 className="w-4 h-4 text-red-400" />
                </button>
              </li>
            ))}
          </ul>
        )}
        {sessions.length > 0 && (
          <button
            className="mt-6 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            onClick={clearHistory}
          >
            Hapus Semua Riwayat
          </button>
        )}
      </div>
    )
  }

  // Update the main return statement
  return (
    <>
      {!isRegistered && <RegistrationForm />}
      <main className="flex h-screen bg-white relative overflow-hidden">
        {/* Overlay for mobile when sidebar is open */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/20 z-10 md:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
        
        {/* Sidebar */}
        <aside className={`
          w-[280px] bg-white border-r border-gray-200 flex flex-col
          transition-all duration-300 ease-in-out
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
          md:translate-x-0
          fixed md:static
          h-full z-20
          md:relative
          shadow-lg md:shadow-none
          max-h-screen
        `}>
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bot className="w-6 h-6" />
              <h1 className="text-xl font-semibold">EDUPUS-AI</h1>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">{userName}</span>
              <button 
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 hover:bg-gray-100 rounded-lg"
                aria-label={sidebarOpen ? "Tutup sidebar" : "Buka sidebar"}
              >
                <Menu className="w-5 h-5" />
              </button>
            </div>
          </div>

          <nav className="flex-1 overflow-y-auto px-3 py-2">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleMenuClick(item.id)}
                className="w-full flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg text-sm"
              >
                {item.icon}
                {item.label}
                {item.isNew && (
                  <span className="ml-auto text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">
                    Baru
                  </span>
                )}
              </button>
            ))}
          </nav>

          <div className="p-3 border-t border-gray-200">
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg text-sm"
            >
              <LogOut className="w-4 h-4" />
              Keluar
            </button>
          </div>
        </aside>

        {/* Main Chat Area */}
        <section className="flex-1 flex flex-col w-full min-h-0">
          <header className="border-b border-gray-200 px-4 sm:px-6 py-3 flex justify-between items-center bg-white sticky top-0 z-10">
            <div className="flex items-center gap-2 min-w-0">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 hover:bg-gray-100 rounded-lg md:hidden flex-shrink-0"
                aria-label="Toggle sidebar"
                type="button"
              >
                <Menu className="w-5 h-5" />
              </button>
              <h2 className="text-lg sm:text-xl font-semibold truncate">
                {currentView === "chat" && "Tanya EDUPUS-AI"}
                {currentView === "agents" && "Agen EDUPUS-AI"}
                {currentView === "ide" && "EDUPUS IDE"}
                {currentView === "api" && "Platform API"}
                {currentView === "docs" && "Dokumentasi"}
                {currentView === "history" && "Riwayat Chat"}
              </h2>
            </div>
            {currentView !== "chat" && (
              <button
                onClick={() => setCurrentView("chat")}
                className="text-sm text-gray-600 hover:text-gray-900 px-2 py-1 rounded flex-shrink-0"
                type="button"
              >
                Kembali ke Chat
              </button>
            )}
          </header>

          <div className="flex-1 overflow-y-auto w-full min-h-0">
            {currentView === "chat" ? (
              // Chat view with adjusted padding
              <div className="px-2 sm:px-4 py-4 sm:py-6 max-w-4xl mx-auto">
                {messages.map((message, i) => (
                  <MessageBubble 
                    key={i}
                    message={message}
                  />
                ))}
                {loading && <LoadingBubble />}
                <div ref={endRef} />
              </div>
            ) : currentView === "history" ? (
              <HistoryView />
            ) : currentView === "agents" ? (
              <AgentsView />
            ) : currentView === "ide" ? (
              <IDEView />
            ) : currentView === "api" ? (
              <APIView />
            ) : (
              <DocsView />
            )}
          </div>

          {/* Show input area only in chat view */}
          {currentView === "chat" && (
            <div className="border-t border-gray-200 p-2 bg-white">
              <div className="bg-white border border-gray-200 rounded-xl shadow-sm max-w-4xl mx-auto">
                {/* Quick Actions */}
                <div className="overflow-x-auto">
                  <div className="flex gap-1 px-2 py-2 border-b border-gray-200 min-w-max">
                    {quickActions.map((action: QuickAction) => (
                      <button
                        key={action.id}
                        onClick={() => handleQuickAction(action.id)}
                        className="flex items-center gap-1 px-2 py-1 text-xs sm:text-sm text-gray-600 hover:bg-gray-100 rounded-md whitespace-nowrap"
                        type="button"
                      >
                        {action.icon}
                        <span className="hidden sm:inline">{action.label}</span>
                      </button>
                    ))}
                    <div className="ml-auto flex-shrink-0">
                      <select 
                        className="text-xs sm:text-sm border-0 bg-transparent text-gray-600 pr-4"
                        value={selectedModel}
                        onChange={(e) => setSelectedModel(e.target.value as ModelType)}
                      >
                        <option value="standard">Model Standar</option>
                        <option value="pro">Model Pro</option>
                        <option value="advanced">Model Lanjutan</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Input Area */}
                <div className="flex items-center gap-1 p-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Kirim pesan..."
                    className="flex-1 border-0 focus:ring-0 text-sm py-1 min-w-0"
                    autoComplete="off"
                    autoCorrect="off"
                    autoCapitalize="off"
                    spellCheck="false"
                    style={{ 
                      WebkitAppearance: 'none',
                      MozAppearance: 'none',
                      appearance: 'none'
                    }}
                  />
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button 
                      onClick={toggleVoiceRecording}
                      className={`p-1 ${isRecording ? 'text-red-500' : 'text-gray-400'} hover:text-gray-600`}
                      type="button"
                    >
                      <Mic className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="p-1 text-gray-400 hover:text-gray-600"
                      type="button"
                    >
                      <Upload className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        if (!loading && input.trim()) {
                          sendMessage(e as any)
                        }
                      }}
                      type="button"
                      disabled={loading || !input.trim()}
                      className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Add file input for image and file uploads */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*,.pdf,.doc,.docx,.txt"
            className="hidden"
          />
        </section>
      </main>
    </>
  )
}

function LoadingBubble() {
  return (
    <div className="flex items-center gap-3 p-4">
      <div className="w-8 h-8 rounded-full bg-gray-200 animate-pulse" />
      <div className="space-y-2">
        <div className="h-2 w-48 bg-gray-200 rounded animate-pulse" />
        <div className="h-2 w-32 bg-gray-200 rounded animate-pulse" />
      </div>
    </div>
  )
}
