"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"

export default function RegistrationPage() {
  return (
    <div className="min-h-[60vh] grid place-items-center px-4">
      <div className="w-full max-w-sm">
        <h1 className="text-2xl font-bold text-center">Registration</h1>
        <form className="mt-6 grid gap-4">
          <div>
            <label className="block text-sm mb-1">Nama Lengkap</label>
            <Input placeholder="Nama lengkap" required />
          </div>
          <div>
            <label className="block text-sm mb-1">Email</label>
            <Input type="email" placeholder="you@example.com" required />
          </div>
          <div>
            <label className="block text-sm mb-1">Password</label>
            <Input type="password" placeholder="Minimal 8 karakter" required />
          </div>
          <Button type="submit" className="w-full">
            Daftar
          </Button>
        </form>
        <p className="text-center text-sm text-muted-foreground mt-4">
          Sudah punya akun?{" "}
          <Link href="/login" className="underline">
            Login
          </Link>
        </p>
      </div>
    </div>
  )
}
